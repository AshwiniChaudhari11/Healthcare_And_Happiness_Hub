<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare and happiness hub</title>
</head>
<link rel="stylesheet" href="probiotic.css">

<body>
    <header>
        <nav class="navbar">
            <!-- <li><img src="logo.png" alt="logo"></li> -->
            <div class="flex rightnav">
                <ul class="navigation flex">
                    <li> <a href="home.php">Home</a></li>
                    <li> <a href="symptom.php">Symptom Checker</a> </li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="#">Medication</a>
                        <ul class="dropdown">
                            <li><a href="homeo.php">Homeopathic</a></li>
                            <li><a href="ayurvedic.php">Ayurvedic</a></li>
                            <li><a href="naturo.php">Naturopathic</a></li>
                        </ul>
                    <li><a href="login.html">Login</a></li>
                    <!-- <li><a href="feedback.html">Feedback</a></li> -->
                    <div class="right">
                        <input type="text" name="search" id="search">
                        <button class="pri-btn">Search</button>
                    </div>

                </ul>
            </div>
        </nav>
    </header>
    <main>
        <div class="prob">
            <div>
                <h1>10 Probiotic foods for good health</h1>
            </div>

            <div>
                <img src="probiotic1.png" alt="">
            </div>
            <div class="parag">
                <p>Probiotic foods refer to types of foods that contain live microorganisms, specifically beneficial
                    bacteria or yeast, which confer health benefits when consumed in adequate amounts. These
                    microorganisms are often referred to as "probiotics." Probiotics are believed to support and
                    maintain a healthy balance of microflora (bacteria) in the digestive system, which is essential for
                    overall health.

                    The most common types of probiotics found in foods belong to the genera Lactobacillus and
                    Bifidobacterium. These beneficial bacteria can aid in digestion, support immune function, and
                    contribute to gut health by promoting the growth of good bacteria and inhibiting the growth of
                    harmful bacteria.

                    Probiotic foods are typically fermented, meaning that they undergo a process where beneficial
                    bacteria or yeast convert sugars and other carbohydrates into organic acids or alcohol. This
                    fermentation process not only preserves the food but also enhances its nutritional value and
                    introduces probiotic microorganisms.</p>
            </div>
            <div class="box"></div>
            <div>
                <h2>Sources for Probiotic foods in India</h2>
            </div>
            <div class="prob1">
                <h4>Dahi (Yogurt):</h4>
                <p>Dahi, also known as yogurt, is a staple in Indian cuisine and is made by fermenting milk with live
                    cultures of bacteria, such as Lactobacillus bulgaricus and Streptococcus thermophilus.
                    It has a creamy texture and slightly tangy flavor, making it a versatile ingredient in dishes like
                    raita, lassi, and curries.
                    Dahi is rich in calcium, protein, and probiotics, which support gut health, aid digestion, and boost
                    immunity.
                    It is often consumed plain, flavored with fruits or spices, or used as a marinade for meat or
                    vegetables.</p>
<hr>
                <h4>Buttermilk (Chaas):</h4>
                <p>Buttermilk, known as chaas in India, is a refreshing beverage made by diluting yogurt with water and
                    adding spices like cumin, salt, and mint.
                    It has a thin consistency and a slightly sour taste, making it a popular drink during hot summer
                    months.
                    Buttermilk contains probiotic bacteria and is a good source of calcium, vitamins, and minerals.
                    It aids digestion, cools the body, and provides hydration, making it an ideal accompaniment to spicy
                    Indian meals.</p><hr>
                <h4>Idli and Dosa Batter:</h4>
                <p>Idli and dosa are popular South Indian dishes made from fermented rice and lentil batter.
                    The fermentation process involves the action of naturally occurring bacteria and yeast, which
                    produce probiotics and enhance the flavor and texture of the batter.
                    Idli and dosa batter is rich in probiotic bacteria, vitamins, and minerals, making it a nutritious
                    and easily digestible option for breakfast or snacks.
                    Fermented rice and lentil batter can be steamed to make soft and fluffy idlis or cooked into thin
                    and crispy dosas, served with chutneys and sambar.</p><hr>
                <h4>Pickles (Achaar):</h4>
                <p>Indian pickles, or achaar, are made by fermenting vegetables or fruits with salt, spices, and oil.
                    The fermentation process produces probiotic bacteria, which help preserve the pickles and enhance
                    their flavor and nutritional value.
                    Common varieties of Indian pickles include mango pickle, lime pickle, and mixed vegetable pickle.
                    Indian pickles are often spicy and tangy, and they are served as condiments or side dishes to
                    complement rice, roti, or dal.</p><hr>
                <h4>Kanji:</h4>
                <p>Kanji is a traditional North Indian probiotic beverage made by fermenting black carrots with water,
                    mustard seeds, and spices like black salt and red chili powder.
                    The fermentation process produces probiotic bacteria, giving kanji its tangy flavor and fizzy
                    texture.
                    Kanji is typically consumed during festivals like Holi and Diwali and is believed to aid digestion
                    and boost immunity.
                    It is served chilled and is known for its refreshing taste and digestive benefits.
                </p><hr>
                <h4>Kadhi:</h4>
                <p>Kadhi is a popular Indian yogurt-based curry made by combining yogurt with besan (gram flour) and
                    spices like turmeric, cumin, and fenugreek seeds.
                    The fermentation of yogurt adds probiotic bacteria to kadhi, contributing to its tangy flavor and
                    creamy texture.
                    Kadhi is often served with rice or roti and is known for its comforting and digestive properties.
                    It is a staple dish in many Indian households and is enjoyed as a wholesome and nutritious meal.</p><hr>
                <h4>Appam:</h4>
                <p>Appam is a South Indian pancake made from fermented rice batter and coconut milk.
                    The fermentation process involves natural bacteria and yeast, which produce probiotics and give
                    appam its characteristic flavor and soft, spongy texture.
                    Appam is typically served with coconut milk, stew, or chutney and is a popular breakfast or snack
                    item in Kerala and Tamil Nadu.
                    It is gluten-free, low in fat, and easily digestible, making it suitable for individuals with
                    dietary restrictions or digestive issues.</p><hr>
                <h4>Dhokla:</h4>
                <p>Dhokla is a savory steamed cake made from fermented rice and chickpea flour batter.
                    The fermentation of the batter produces probiotic bacteria, which contribute to dhokla's light and
                    fluffy texture and tangy flavor.
                    Dhokla is a popular snack in Gujarat and other parts of India and is often served with green chutney
                    or sweet and tangy tamarind chutney.
                    It is a nutritious and protein-rich dish, making it a healthy option for breakfast, brunch, or
                    tea-time snacks.</p><hr>
                <h4>Fermented Rice (Panta Bhat):</h4>
                <p>Panta Bhat is a traditional Bengali dish made by soaking cooked rice in water overnight until it
                    ferments.
                    The fermentation process produces probiotic bacteria, which give panta bhat its sour flavor and soft
                    texture.
                    Panta Bhat is typically served with salt, green chilies, and fried fish or vegetables and is enjoyed
                    as a cooling and refreshing meal during hot summer months.
                    It is believed to have digestive and cooling properties, making it a popular choice for combating
                    heat-related illnesses.</p><hr>
                <h4>Gundruk:</h4>
                <p>Gundruk is a fermented leafy green vegetable dish originating from the Himalayan regions of India,
                    Nepal, and Bhutan.
                    It is made by fermenting leafy greens like mustard greens, spinach, or radish leaves and drying them
                    in the sun.
                    The fermentation process produces probiotic bacteria, which preserve the greens and enhance their
                    flavor and nutritional value.
                    Gundruk is typically cooked with spices and served as a side dish or added to soups, stews, and
                    lentil dishes.
                    It is rich in vitamins, minerals, and antioxidants, making it a nutritious and flavorful addition to
                    the diet.</p>
            </div>
        </div>
    </main>
    <footer>
        <div class="flex foot">
            <div class="hcube">H & H Hub</div>
            <div class="f1">
                <ul>
                    <li><a href="">Depression</a></li>
                    <li><a href="">Weight Loss</a> </li>
                    <li><a href=""> Healthy Living</a></li>
                </ul>

            </div>
            <div class="f2">
                <ul>
                    <li><a href="">Healthy Eating</a></li>
                    <li><a href="">Skin Health</a> </li>
                    <li><a href=""> Mental Health</a></li>
                </ul>
            </div>
            <div class="f3">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
            <div class="f4">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
        </div>
        <div class="f5">
            <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
                empower individuals to take proactive steps towards optimal well - being, where every click brings you
                closer to vitality and vitality.</p>
        </div>
    </footer>
    <div class="ll">
        www.healthandhappinesshub.com | <a href="contact.html">Contact us</a>
    </div>
</body>

</html>