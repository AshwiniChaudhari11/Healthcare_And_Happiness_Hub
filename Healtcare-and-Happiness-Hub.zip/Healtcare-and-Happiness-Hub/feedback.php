<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        textarea {
            height: 100px;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Feedback Form</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" required></textarea><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
        $name = $_POST["name"];
        $email = $_POST["email"];
        $message = $_POST["message"];

      
        $feedbackData = "Name: $name\nEmail: $email\nMessage: $message\n\n";

        $feedbackFile = "feedback.txt";
        if (file_put_contents($feedbackFile, $feedbackData, FILE_APPEND | LOCK_EX) !== false) {
            echo "Thank you for your feedback!";
            require_once "databasef.php";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
               
                $name = $_POST["name"];
                $email = $_POST["email"];
                $message = $_POST["message"];
            
            
                $feedbackData = "Name: $name\nEmail: $email\nMessage: $message\n\n";
            
                $sql = "INSERT INTO feedbackofuser (Name, email, feedback) VALUES ('$name', '$email', '$message')";
                if (mysqli_query($conn, $sql)) {
                    echo "Thank you for your feedback!";
                } else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
            }
        } else {
            echo "Error occurred while submitting feedback.";
        }
    }
    ?>

</div>

</body>
</html>
