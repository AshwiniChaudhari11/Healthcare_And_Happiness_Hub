<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare and Happiness Hub</title>
    <link rel="stylesheet" href="ayurvedic.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="flex rightnav">
                <ul class="navigation flex">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="symptom.php">Symptom Checker</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li>
                        <a href="#">Medication</a>
                        <ul class="dropdown">
                            <li><a href="homeo.php">Homeopathic</a></li>
                            <li><a href="ayurvedic.php">Ayurvedic</a></li>
                            <li><a href="naturo.php">Naturopathic</a></li>
                        </ul>
                    </li>
                    <li><a href="registration.php">Login</a></li>
                </ul>
                <div class="right">
                    <input type="text" name="search" id="search">
                    <button class="pri-btn">Search</button>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="left">
            <h1>Ayurveda</h1>
            <h2>Discover Traditional Healing:</h2>
            <h3>"Embrace Harmony with Ayurvedic Wisdom"</h3>
            <h4>Unlock the ancient secrets of Ayurveda and experience the balance and vitality it brings to your life. Dive into the world of holistic healing with our carefully curated Ayurvedic solutions.</h4>
        </div>
        <div class="container">
            <h1>Get Ayurvedic Solution</h1>
            <label for="healthCondition">Enter Your Health Condition:</label>
            <input type="text" id="healthCondition" placeholder="e.g., Digestive Issues">
            <button class="sec-btn" onclick="getAyurvedicSolution()">Get Solution</button>
            <div id="solution"></div>
        </div>
    </main>
    <footer>
        <div class="flex foot">
            <div class="hcube">H & H Hub</div>
            <div class="f1">
                <ul>
                    <li><a href="">Depression</a></li>
                    <li><a href="">Weight Loss</a></li>
                    <li><a href="">Healthy Living</a></li>
                </ul>
            </div>
            <div class="f2">
                <ul>
                    <li><a href="">Healthy Eating</a></li>
                    <li><a href="">Skin Health</a></li>
                    <li><a href="">Mental Health</a></li>
                </ul>
            </div>
            <div class="f3">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a></li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
            <div class="f4">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a></li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
        </div>
        <div class="f5">
            <p>By combining cutting-edge technology with a positive approach to healthcare, our website tries to empower individuals to take proactive steps towards optimal well-being, where every click brings you closer to vitality and vitality.</p>
        </div>
    </footer>
    <div class="ll">
        www.healthandhappinesshub.com | <a href="contact.html">Contact us</a>
    </div>
    <script src="ayurvedic.js"></script>
</body>
</html>
