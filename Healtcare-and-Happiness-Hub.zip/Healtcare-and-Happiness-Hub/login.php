<?php
session_start();

if (isset($_SESSION["user"])) {
   header("Location: index.php");
   exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "feedback";

    // Establish database connection
    $conn = mysqli_connect($hostname, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL statement with LIKE clause for email search
    $email = $_POST["email"];
    $email = '%' . $email . '%'; // Append wildcard '%' to the email
    $sql = "SELECT * FROM user WHERE email LIKE ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Check for errors during preparation
    if (!$stmt) {
        die("Preparation of SQL statement failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        $password = $_POST["password"];
        if (password_verify($password, $user["pass"])) {
            $_SESSION["user"] = "yes";
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Password does not match";
        }
    } else {
        $error_message = "Email does not exist";
    }
    if ($user) {
        // Debugging: Output hashed password from the database and password entered by the user
        echo "Hashed Password from Database: " . $user["pass"] . "<br>";
        echo "Password Entered by User: " . $password . "<br>";
    
        if (password_verify($password, $user["pass"])) {
            $_SESSION["user"] = "yes";
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Password does not match";
        }
    }
    
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form action="login.php" method="post">
            <div class="form-group">
                <input type="email" placeholder="Enter Email:" name="email" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Enter Password:" name="password" class="form-control">
            </div>
            <div class="form-btn">
                <input type="submit" value="Login" name="login" class="btn btn-primary">
            </div>
        </form>
        <div>
            <p>Not registered yet <a href="registration.php">Register Here</a></p>
        </div>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
