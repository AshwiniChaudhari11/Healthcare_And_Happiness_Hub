<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare and Happiness Hub</title>
    <link rel="stylesheet" href="homeo.css">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="flex rightnav">
                <ul class="navigation flex">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="symptom.php">Symptom Checker</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li>
                        <a href="#">Medication</a>
                        <ul class="dropdown">
                            <li><a href="homeo.php">Homeopathic</a></li>
                            <li><a href="ayurvedic.php">Ayurvedic</a></li>
                            <li><a href="naturo.php">Naturopathic</a></li>
                        </ul>
                    </li>
                    <li><a href="registration.php">Login</a></li>
                </ul>
                <div class="right">
                    <input type="text" name="search" id="search">
                    <button class="pri-btn">Search</button>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="left">
            <h1>Homeopathy</h1>
            <h2>Discover Natural Healing:</h2>
            <h3>"Transform Your Health with Homeopathic Solutions"</h3>
            <h4>The power of natural healing and the profound benefits that homeopathy offers for holistic
                well-being. As advocates of alternative medicine, we're dedicated to providing you with
                high-quality homeopathic solutions that nurture your body's innate ability to heal itself.</h4>
        </div>
        <div class="container">
            <h1>Get Homeopathic Solution</h1>
            <label for="healthCondition">Enter Your Health Condition:</label>
            <input type="text" id="healthCondition" placeholder="e.g., Headache">
            <button class="sec-btn" onclick="getHomeopathicSolution()">Get Solution</button>
            <div id="solution"></div>
        </div>
        <script src="homeo.js"></script>
    </main>
    <footer>
        <div class="flex foot">
            <div class="hcube">H & H Hub</div>
            <div class="f1">
                <ul>
                    <li><a href="">Depression</a></li>
                    <li><a href="">Weight Loss</a> </li>
                    <li><a href=""> Healthy Living</a></li>
                </ul>
            </div>
            <div class="f2">
                <ul>
                    <li><a href="">Healthy Eating</a></li>
                    <li><a href="">Skin Health</a> </li>
                    <li><a href=""> Mental Health</a></li>
                </ul>
            </div>
            <div class="f3">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
            <div class="f4">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
        </div>
        <div class="f5">
            <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
                empower individuals to take proactive steps towards optimal well - being, where every click brings you
                closer to vitality and vitality.</p>
        </div>
    </footer>
    <div class="ll">
        www.healthandhappinesshub.com | <a href="contact.html">Contact us</a>
    </div>
    <script src="homeo.js"></script>
</body>

</html>
