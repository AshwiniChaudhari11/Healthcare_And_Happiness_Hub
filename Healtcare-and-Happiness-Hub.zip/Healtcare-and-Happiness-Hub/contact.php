<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Disease Checker</title>
  <link rel="stylesheet" href="contact.css">
</head>

<body>
  <header>
    <nav class="navbar">
      <div class="flex rightnav">
        <ul class="navigation flex">
          <div class="logo">
            <li>H & H Hub</li>
          </div>
          <li><a href="home.php">Home</a></li>
          <li><a href="symptom.php">Symptom</a></li>
          <li><a href="blog.php">Blogs</a></li>
          <li><a href="#">Medication</a>
            <ul class="dropdown">
              <li><a href="homeo.php">Homeopathic</a></li>
              <li><a href="ayurvedic.php">Ayurvedic</a></li>
              <li><a href="naturo.php">Naturopathic</a></li>
            </ul>
          <li><a href="registration.php">Login</a></li>
        </ul>
      </div>
    </nav>
  </header>
  <main>
    <div class="container">
      <h1>Contact us</h1>
      <form id="symptomsForm">
        <div class="flex">
          <label for="name">Enter your Name:</label><br>
          <input type="text" id="name" name="name" required><br>
        </div>
        <div class="flex">
          <label for="email">Enter your Email:</label><br>
          <input type="email" id="email" name="email" required><br>
        </div>
        <div class="flex">
          <label for="mobile">Enter your Mobile Number:</label><br>
          <input type="text" id="mobile" name="mobile" required><br>
        </div>
        <button type="submit">Contact</button>
      </form>
    </div>
  <div class="social">
      <h2>Visit our social sites</h2>
      <div class="flex">
        <div class="image">
          <a href="https://www.instagram.com/">
            <img src="insta.png" alt="Instagram">
          </a>
        </div>
        <div class="image">
          <a href="https://www.facebook.com/">
            <img src="facebook.png" alt="Facebook">
          </a>
        </div>
        <div class="image">
          <a href="https://in.linkedin.com/">
            <img src="linkedin.png" alt="LinkedIn">
          </a>
        </div>
      </div>
      </div>
    
    
    <script>
      document.getElementById("symptomsForm").addEventListener("submit", function (event) {
        event.preventDefault();
        alert("Be prepared! We're about to whisk your message through the internet ether to reach you via SMS or email.");
      });
    </script>
  </main>
  <footer>
    <div class="flex foot">
      <div class="hcube">H & H Hub</div>
      <div class="f1">
        <ul>
          <li><a href="">Depression</a></li>
          <li><a href="">Weight Loss</a> </li>
          <li><a href=""> Healthy Living</a></li>
        </ul>

      </div>
      <div class="f2">
        <ul>
          <li><a href="">Healthy Eating</a></li>
          <li><a href="">Skin Health</a> </li>
          <li><a href=""> Mental Health</a></li>
        </ul>
      </div>
      <div class="f3">
        <ul>
          <li><a href="">Sleep Disorders</a></li>
          <li><a href="">Heart Care</a> </li>
          <li><a href="">Oral Care</a></li>
        </ul>
      </div>
      <div class="f4">
        <ul>
          <li><a href="">Sleep Disorders</a></li>
          <li><a href="">Heart Care</a> </li>
          <li><a href="">Oral Care</a></li>
        </ul>
      </div>
    </div>
    <div class="f5">
      <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
        empower individuals to take proactive steps towards optimal well - being, where every click brings you
        closer to vitality and vitality.</p>
    </div>
  </footer>
</body>

</html>