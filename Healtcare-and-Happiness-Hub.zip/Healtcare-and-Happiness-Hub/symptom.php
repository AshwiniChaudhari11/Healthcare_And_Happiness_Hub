<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Disease Checker</title>
  <link rel="stylesheet" href="symptoms.css">
  <style>
    .feedback-prompt {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: #f9f9f9;
      border: 1px solid #ccc;
      padding: 20px;
      z-index: 9999;
    }

    .feedback-prompt p {
      margin: 0;
    }

    .feedback-prompt button {
      margin-top: 10px;
    }
  </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <!-- <li><img src="logo.png" alt="logo"></li> -->
            <div class="flex rightnav">
                <ul class="navigation flex">
                    <div class="logo">
                        <li>H & H Hub</li>
                    </div>
                    <li> <a href="home.php">Home</a></li>
                    <li> <a href="symptom.php">Symptom</a> </li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="#">Medication</a>
                        <ul class="dropdown">
                            <li><a href="homeo.php">Homeopathic</a></li>
                            <li><a href="ayurvedic.php">Ayurvedic</a></li>
                            <li><a href="naturo.php">Naturopathic</a></li>
                        </ul>
                    <li><a href="feedback.php">feedback</a></li>
                    <!-- <li><a href="feedback.html">Feedback</a></li> -->
                </ul>
            </div>
        </nav>
    </header>
    <main>
      <div class="container">
        <h1>Disease Checker</h1>
        <form id="symptomsForm">
            <label for="age">Age:</label><br>
            
            <input type="number" id="age" name="age" required><br>
            <label for="gender">Gender:</label><br>
            <select id="gender" name="gender" required>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select><br>
            <label for="symptoms">Enter your symptoms separated by commas:</label><br>
            <input type="text" id="symptoms" name="symptoms" required><br>
            <button type="submit">Check Diseases</button>
        </form>
        
        <div id="result"></div>
      </div>

      <!-- Feedback prompt -->
      <div class="feedback-prompt" id="feedbackPrompt">
        <p>Thank you for using our Disease Checker! Would you like to give us feedback?</p>
        <button onclick="window.location.href='feedback.php';">Yes</button>
        <button onclick="closeFeedbackPrompt();">No, Thanks</button>
      </div>
      <script src="script.js"></script>
    </main>
      <footer>
    <div class="flex foot">
        <div class="hcube">H & H Hub</div>
        <div class="f1">
            <ul>
                <li><a href="">Depression</a></li>
                <li><a href="">Weight Loss</a> </li>
                <li><a href=""> Healthy Living</a></li>
            </ul>

        </div>
        <div class="f2">
            <ul>
                <li><a href="">Healthy Eating</a></li>
                <li><a href="">Skin Health</a> </li>
                <li><a href=""> Mental Health</a></li>
            </ul>
        </div>
        <div class="f3">
            <ul>
                <li><a href="">Sleep Disorders</a></li>
                <li><a href="">Heart Care</a> </li>
                <li><a href="">Oral Care</a></li>
            </ul>
        </div>
        <div class="f4">
            <ul>
                <li><a href="">Sleep Disorders</a></li>
                <li><a href="">Heart Care</a> </li>
                <li><a href="">Oral Care</a></li>
            </ul>
        </div>
    </div>
    <div class="f5">
        <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
            empower individuals to take proactive steps towards optimal well - being, where every click brings you
            closer to vitality and vitality.</p>
    </div>
</footer>
</body>
</html>
