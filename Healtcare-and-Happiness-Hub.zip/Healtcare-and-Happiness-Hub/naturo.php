<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare and happiness hub</title>
</head>
<link rel="stylesheet" href="naturo.css">

<body>
    <header>
        <nav class="navbar">
            <!-- <li><img src="logo.png" alt="logo"></li> -->
            <div class="flex rightnav">
                <ul class="navigation flex">
                    <li> <a href="home.php">Home</a></li>
                    <li> <a href="symptom.php">Symptom Checker</a> </li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="#">Medication</a>
                        <ul class="dropdown">
                            <li><a href="homeo.php">Homeopathic</a></li>
                            <li><a href="ayurvedic.php">Ayurvedic</a></li>
                            <li><a href="naturo.php">Naturopathic</a></li>
                        </ul>
                    <li><a href="register.php">Login</a></li>
                    <!-- <li><a href="feedback.html">Feedback</a></li> -->
                    <div class="right">
                        <input type="text" name="search" id="search">
                        <button class="pri-btn">Search</button>
                    </div>

                </ul>
            </div>
        </nav>
    </header>
    <main>
        <div>

            <div class="homeo flex">

                <div class="left">
                    <h1>Naturopathy</h1>
                    <h2>Embrace Natural Healing:</h2>
                    <h3> Discover the Power of Naturopathy"</h3>
                    <h4>At Health & Happinesss Hub, we're passionate about promoting health and wellness through the
                        principles of naturopathic medicine. Our mission is to empower individuals to take control of
                        their health and vitality using natural, holistic approaches that address the root causes of
                        illness.</h4>
                </div>
                <div class="container">
                    <h1>Get Naturopathic Solution</h1>
                    <label for="healthCondition">Enter Your Health Condition:</label>
                    <input type="text" id="healthCondition" placeholder="e.g., Headache">
                    <button class="sec-btn" onclick="getSolution()">Get Solution</button>
                    <div id="solution"></div>
                </div>


            </div>
        </div>
        <div>
            <h2>What is Naturopathic Medicine?</h2>
            <p>
                Naturopathic medicine is a holistic approach to healthcare that emphasizes prevention, individualized
                treatment, and the body's innate ability to heal itself. Naturopathic doctors (NDs) combine traditional
                healing wisdom with modern scientific research to provide comprehensive and personalized care.
            </p>
            <h2>The Principles of Naturopathy</h2>
            <p><b>First, Do No Harm: </b> Naturopathic medicine seeks to utilize the least invasive and least harmful
                therapies to promote healing while avoiding the suppression of symptoms.</p>
            <p><b>Treat the Whole Person: </b>Rather than focusing solely on symptoms or isolated parts of the body,
                naturopathic doctors consider the physical, mental, emotional, and spiritual aspects of a person's
                health.
            </p>
            <p><b>Identify and Treat the Root Cause:</b> Naturopathic medicine aims to uncover and address the
                underlying causes of illness, rather than just treating symptoms superficially.</p>
            <p><b>Doctor as Teacher:
                </b>Naturopathic doctors educate and empower their patients to take an active role in their own health
                by providing knowledge and guidance on lifestyle modifications, nutrition, and self-care practices.</p>
            <p>
                    <b>Prevention is the Best Medicine:</b> Naturopathic medicine emphasizes the importance of preventive care and lifestyle interventions to optimize health and reduce the risk of future illness.
            </p>
            <h2>Our Naturopathic Services</h2>
            <p>At Health and Happinesss Hub, we offer a range of naturopathic services designed to support your journey to optimal health and vitality. Whether you're seeking relief from chronic health conditions, support for stress management, or guidance on achieving your wellness goals,You will get all the solutions </p>
        </div>
    </main>
    <footer>
        <div class="flex foot">
            <div class="hcube">H & H Hub</div>
            <div class="f1">
                <ul>
                    <li><a href="">Depression</a></li>
                    <li><a href="">Weight Loss</a> </li>
                    <li><a href=""> Healthy Living</a></li>
                </ul>

            </div>
            <div class="f2">
                <ul>
                    <li><a href="">Healthy Eating</a></li>
                    <li><a href="">Skin Health</a> </li>
                    <li><a href=""> Mental Health</a></li>
                </ul>
            </div>
            <div class="f3">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
            <div class="f4">
                <ul>
                    <li><a href="">Sleep Disorders</a></li>
                    <li><a href="">Heart Care</a> </li>
                    <li><a href="">Oral Care</a></li>
                </ul>
            </div>
        </div>
        <div class="f5">
            <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
                empower individuals to take proactive steps towards optimal well - being, where every click brings you
                closer to vitality and vitality.</p>
        </div>
    </footer>
    <div class="ll">
        www.healthandhappinesshub.com | <a href="contact.html">Contact us</a>
    </div>
</body>

</html>