# Healtcare-and-Happiness-Hub
This is the mini project of a health care website provides disease checker , medications, login and registration and feedback options
