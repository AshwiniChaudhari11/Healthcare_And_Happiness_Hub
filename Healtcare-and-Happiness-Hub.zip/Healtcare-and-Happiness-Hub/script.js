const diseaseData = {
    "Common Cold": ["runny nose", "sneezing", "cough"],
    "Flu": ["fever", "chills", "body aches", "fatigue"],
    "Allergies": ["itchy eyes", "sneezing", "runny nose"],
    "Pneumonia":["High fever", "cough", "difficulty breathing", "chest pain"],
    "Asthma":["Shortness of breath", "Wheezing", "chest tightness", "cough"],
    "Strep Throat":["Sore throat", "fever", "Difficulty swallowing", "Swollen tonsils"],
    "Gastroenteritis(Stomach flu)":["Nausea", "Vomiting", "Diarrhea", "Abdominal cramps"],
    "Urinary Tract Infection (UIT)":["Burning while urinating", "urge to urinate", "cloudy urine", "bloody urine", "pain in lower abdomen"],
    "Diabetes":["Increased thirst", "Frequent urination", "fatigue","Blurred vision"],
    "Hypertension (High Blood Pressure)":["Headaches", "Dizziness","lightheadness", "blurred vision","chest pain"],
    "Dengue fever":["High fever", "headache","eye pain", "joint pain", "muscle pain","fatigue","nausea","vomiting","skin rash"],
    "Maleria":["Fever", "chills", "sweat", "headache","nausea","vomiting","musle pain","fatique"],
    "Chikungunya":["Sudden fever","joint pain","muscle pain","headache", "nausea", "fatigue","rash"],
    "Typhoid":["High fever", "weakness","stomach pain", "headache","loss of appetite","constipation","diarrhea","rash"],
    "Tuberculosis (TB)":["blood cough","chest pain", "fatigue","weight loss","fever","night sweats"],

};

function findDiseases(symptoms) {
    const diseaseCounts = {};
    for (const disease in diseaseData) {
        const diseaseSymptoms = diseaseData[disease];
        const count = symptoms.filter(symptom => diseaseSymptoms.includes(symptom)).length;
        if (count > 0) {
            diseaseCounts[disease] = count;
        }
    }

    // Find the maximum number of matching symptoms
    const maxCount = Math.max(...Object.values(diseaseCounts));

    // Find diseases with the maximum number of matching symptoms
    const potentialDiseases = Object.keys(diseaseCounts).filter(disease => diseaseCounts[disease] === maxCount);

    return potentialDiseases;
}
function promptFeedback() {
    setTimeout(function() {
      document.getElementById('feedbackPrompt').style.display = 'block';
    }, 20000); // 20 seconds delay
  }

  function closeFeedbackPrompt() {
    document.getElementById('feedbackPrompt').style.display = 'none';
  }

  document.addEventListener("DOMContentLoaded", function() {
      promptFeedback();
  });
function handleSubmit(event) {
    event.preventDefault();
    const userSymptoms = document.getElementById('symptoms').value
        .toLowerCase()
        .split(",")
        .map(symptom => symptom.trim()); 
    const potentialDiseases = findDiseases(userSymptoms);
    const resultDiv = document.getElementById('result');
    if (potentialDiseases.length > 0) {
        resultDiv.innerHTML = "<p>Based on your symptoms, you may have the following diseases:</p>";
        potentialDiseases.forEach(disease => {
            resultDiv.innerHTML += "<p>- " + disease + "</p>";
        });
        resultDiv.innerHTML +="<p>To get expected result Enter the more symptoms if you are facing:</p>";
    } else {
        resultDiv.innerHTML = "<p>No diseases found based on your symptoms.</p>";
    }
}

document.getElementById('symptomsForm').addEventListener('submit', handleSubmit);
