<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare and happiness hub</title>
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <h2>Health and Happiness Hub</h2>
    <header>

        <header>
            <nav class="navbar">
                <!-- <li><img src="logo.png" alt="logo"></li> -->
                <div class="flex rightnav">
                    <ul class="navigation flex">
                        <div class="logo">
                            <li>H & H Hub</li>
                        </div>
                        <li> <a href="home.php">Home</a></li>
                        <li> <a href="symptom.php">Symptoms Checker</a> </li>
                        <li><a href="blog.php">Blogs</a></li>
                        <li><a href="#">Medication</a>
                            <ul class="dropdown">
                                <li><a href="homeo.php">Homeopathic</a></li>
                                <li><a href="ayurvedic.php">Ayurvedic</a></li>
                                <li><a href="naturo.php">Naturopathic</a></li>
                            </ul>
                        <li><a href="registration.php">Login</a></li>
                        <!-- <li><a href="feedback.html">Feedback</a></li> -->
                        <div class="right">
                            <input type="text" name="search" id="search">
                            <button class="pri-btn">Search</button>
                        </div>

                    </ul>
                </div>
            </nav>
        </header>
        <main>
            <section>
                <div class="box">
                    <img src="home.png" alt="">
                </div>
                <!-- <h3 class="text-overlay">Welcome to</h3> -->
                <!-- <h2 class="text-overlay1" >Health and Happiness Hub</h2> -->
                <span id="element" class="text-overlay3 box1"></span>
            </section>
            <section class="section2 flex">
                <div class="boxsec">
                    <div class="p">
                        Healthy Eating
                    </div>
                    <div class="flex">
                        <div>
                            <img src="probiotic.png" alt="">
                            <img src="fasting.png" alt="">
                            <img src="lemonjuice.png" alt="">
                        </div>
                        <div>
                            <div class="health blue">
                                <a href="probiotic.php">10 Probotic food to suppurt your health</a>
                            </div>
                            <div class="health1 blue">
                                <a href="fasting.php">Is Intermittent fasting safe?</a>
                            </div>
                            <div class="health2 blue">
                                <a href="lemon.php">Benifits of dinking lemon juice</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="boxsec1">
                    <div class="p">
                        Wellbeing
                    </div>
                    <div>
                        <div class="flex">
                            <div>
                                <img src="running1.png" alt="">
                                <img src="swim.png" alt="">
                                <img src="yoga.png" alt="">
                            </div>
                            <div>
                                <div class="health blue">
                                    <a href="running.php">How to start running: for beginners</a>
                                </div>
                                <div class="health1 blue">
                                    <a href="coldwater.php">Cold water swimming : Benifits annd risks</a>
                                </div>
                                <div class="health2 blue">
                                    <a href="yoga.php">Benifits of morning yoga</a>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
            <script>
    // Function to display registration prompt only once
    function displayRegistrationPrompt() {
        // Check if the prompt has been shown before by checking a browser cookie
        var promptShown = getCookie("promptShown");
        if (!promptShown) {
            // Display the prompt
            var promptOverlay = document.createElement('div');
            promptOverlay.classList.add('prompt-overlay');
            promptOverlay.innerHTML = `
                <p>Welcome to Health and Happiness Hub! Register now to access the full features.</p>
                <button onclick="registerAndClosePrompt()">Register</button>
            `;
            document.body.appendChild(promptOverlay);

            // Set a cookie to indicate that the prompt has been shown
            setCookie("promptShown", true, 365); // Expires after 365 days
        }
    }

    // Function to set a browser cookie
    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }


    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function registerAndClosePrompt() {
       
        window.location.href = "registration.php";
       
        var promptOverlay = document.querySelector('.prompt-overlay');
        if (promptOverlay) {
            promptOverlay.remove();
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
      
        displayRegistrationPrompt();
    });
</script>

        </main>
        <footer>
            <div class="flex foot">
                <div class="hcube">H & H Hub</div>
                <div class="f1">
                    <ul>
                        <li><a href="">Depression</a></li>
                        <li><a href="">Weight Loss</a> </li>
                        <li><a href=""> Healthy Living</a></li>
                    </ul>

                </div>
                <div class="f2">
                    <ul>
                        <li><a href="">Healthy Eating</a></li>
                        <li><a href="">Skin Health</a> </li>
                        <li><a href=""> Mental Health</a></li>
                    </ul>
                </div>
                <div class="f3">
                    <ul>
                        <li><a href="">Sleep Disorders</a></li>
                        <li><a href="">Heart Care</a> </li>
                        <li><a href="">Oral Care</a></li>
                    </ul>
                </div>
                <div class="f4">
                    <ul>
                        <li><a href="">Sleep Disorders</a></li>
                        <li><a href="">Heart Care</a> </li>
                        <li><a href="">Oral Care</a></li>
                    </ul>
                </div>
            </div>
            <div class="f5">
                <p> By combining cutting - edge technology with a positive approach to healthcare, our website tries to
                    empower individuals to take proactive steps towards optimal well - being, where every click brings
                    you closer to vitality and vitality.</p>
            </div>
        </footer>
        <div class="ll">
            www.healthandhappinesshub.com | <a href="contact.php">Contact us</a>
        </div>
        <script src="https://unpkg.com/typed.js@2.1.0/dist/typed.umd.js"></script>
        <script>
            var typed = new Typed('#element', {
                strings: ['Wellness Blogs and Articles', ' Symptoms Checker and Health Information', '&amp; Ayurvedic, Naturopathic, and Homeopathic solutions .'],
                typeSpeed: 40,
            });
        </script>
</body>

</html>