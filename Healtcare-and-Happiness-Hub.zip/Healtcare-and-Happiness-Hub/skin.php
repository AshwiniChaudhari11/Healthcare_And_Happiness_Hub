<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depression </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
            color: #121114;
        }

        header {
            background-color: #604e84;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #4f4c7c;
            padding: 10px;
            text-align: center;
        }

        nav {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .depress {
            height: 100px;
            width: 9%;
            padding: 90px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 0 20px;
        }


        .post {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        image {
            height: 100px;
            width: 100px;
            padding: 9%;

        }

        .post h2 {
            color: #333;
        }

        .post p {
            color: #666;
        }
    </style>
</head>

<body>
    <header>
        <h1> Skin Care</h1>
    </header>
    <br>
    <nav><b></b>
    </nav>
    <div class="container">
        <div class="post">
            <h2>Importance of Skincare in Overall Health:
                <div class="image">
                    <img src="n.png">
                </div>

            </h2>

            <p><b>
                    Skincare is important for overall health because skin is the body's largest organ and first line of
                    defense against bacteria, infection, and environmental hazards.
                    <br> A proper skincare routine can help:<br>
                    <ul>

                        <li> Protect against bacteria and infection<br></li>
                        <li> Remove irritants and bacteria from the skin's surface to prevent them from clogging pores
                            or being
                            absorbed into the body<br></li>
                        <li> Protect against the sun's UV rays<br></li>
                        <li> Skin cancer is the most common type of cancer and can occur in people of all ages<br> </li>
                        <li> Regulate body temperature<br></li>
                        <li> Dry, dull, or blemished skin can make people feel self-conscious and affect their
                            confidence<br>
                            <br>
                        </li>
                        <li>Improve appearance and self-esteem<br> </li>
                        <li> Prevent premature aging and skin conditions</li>

                        <br>

                    </ul>

            </p>

        </div>
        <div class="post">
            <h2> Natural Beauty Remedies:
                <div class="image">
                    <img src="skin.png">
                </div>

            </h2>


            <p>
                <b> Glowing skin is one way to describe healthy skin. Here are ways to enhance your skin that you can do
                    at home.
                    <br>
                    Your skin is the largest organ that you have, so you want to take care of it. <br> 
                    <br> Glowing skin is typically seen as a sign of health and vitality. Dull or dry skin, on the other
                    hand, can make you feel less than
                    your best.
                    <br>
                 
                    <br> The best part? You probably already have everything you need in your pantry, kitchen, or
                    medicine cabinet.
                </b>
            </p> <br> 
            <p><b>
                1. Soothe skin with virgin coconut oil:
                <br> <br> 
                Coconut oil has anti-inflammatory, antioxidant, and healing properties. But using coconut oil on your
                face may not work for every skin type. Do not use if you have allergies to coconut.

                If you’re able to apply it without irritation, it can be used in a number of ways. You can use coconut
                oil to:
            <ul>
                <li>
                    take off makeup
                </li>
                <li>
                    soothe your skin barrier
                </li>
                <li>
                    promote dewy-looking skin that’s healthy below the surface layer

                </li>
                <li>
                    Research shows that coconut oil is a good moisturizer. <br>Try massaging a small amount of coconut
                    oil onto
                    your face.
                     <br>Let it soak in for a few minutes before washing off with your normal cleanser.

                </li>
            </ul>
            
            </b>
            </p> <br> 
            <p><b>
                    2. Use aloe vera to keep skin strong and healthy:
                    <br> <br> 
                    Aloe vera has healing properties and may stimulate new cell growth. It also soothes and moisturizes
                    without clogging pores. Using aloe vera after you’ve washed your face each day may give your skin
                    that
                    healthy glow.
                    It’s possible to be allergic to aloe vera. Test it first by rubbing a small amount on your forearm
                    and
                    if there’s no reaction in 24 hours, it should be safe to use.

                    Find purchasing options for aloe vera online.
                </b>
            </p> <br> 
            <p><b>
                    3. Moisturize properly after washing your face:
                    <br> <br> 
                    Moisturize your skin with products that lock in moisture, promote healing, and have antioxidant
                    properties to encourage a glowing, youthful look. Don’t exfoliate your skin when it feels dry, and
                    don’t
                    skip moisturizer just because your face feels oily.

                    Apply moisturizer to your skin when it’s still wet from a shower or from rinsing your face. This
                    will
                    lock in extra moisture rather than working on a surface level to make your face feel smooth.

                    See moisturizers for sale.
                </b>
            </p> <br> 
            <p><b>
                    4. Wear sunscreen daily:
                    <br> <br> 
                    Wearing sunscreen with an SPF of 15 or above can prevent skin cancer. Keeping your skin shielded
                    from
                    harmful UV rays also guards against photoaging, which is the process of skin aging.

                    Make sure to apply a product with sunscreen every morning, even on days when it’s raining or the sky
                    is
                    overcast.

                    Stock up on sunscreen here.
                </b>
            </p> <br> 
            <p><b>

                    5. Find a cleansing routine that works:
                    <br> <br> 
                    You don’t want to rob your skin of moisture by washing it too often, and you don’t want to encourage
                    your pores to produce too much extra oil to compensate for too much washing.
                    Washing your face after you’ve worked up a sweat, first thing in the morning, and right before bed
                    is
                    typically the sweet spot for healthy skin.
                </b>
            </p> <br> 
            <p><b>
                    6. Avoid smoke and secondhand smoke:
                    <br> <br> 
                    When you expose your skin to cigarette smoke, you’re coating your face with all sorts of chemical
                    toxins. This ups the oxidative stress in your skin cells, leading to prematurely aged skin.

                    If you smoke, consider your skin as another reason to quit.
                </b>
            </p> <br> 
            <p><b>
                    7. Drink more water:
                    <br> <br> 
                    Your skin is made up of cells that need water to function well. The connection to drinking water and
                    having healthy skin is still ongoing, but at least one 2015 study concluded there’s a strong link
                    between drinking more water and having healthier skin.

                    Aim for at least eight 8-ounce glasses of water per day.
                </b>



            </p>
            <br><br>

            </p>
        </div>
        <div class="post">
            <h2> Tips for Maintaining Healthy Hair and Nails:

            </h2>
            <br> 

            <p><b>
                Shiny hair, glowing skin, and strong nails are often seen as external symbols of health. But there’s
                more to it than that.
                <br> 
                You’ve probably heard it said that the skin is the largest organ in the body.
                <br> 
           </b> </p>
           <br> 
            <p>
            <h3>For hair</h3>
            <div class="image">
                <img src="haiir.png">
            </div><b>
            Rimmer recommends looking for products that contain ketoconazole.
            <br> 
            It’s an ingredient in shampoo Fused to treat fungal infections, but it can also be useful for those with
            thinning hair.  <br> It’s “commonly prescribed as a first line supplement to help with thinning hair. <br>  <br>
            There have been studies to demonstrate a thickening of the hair shaft and number of hairs” with it’s use.
            <br> <br>
            Sadri also recommends looking for products with the following ingredients: <br>
            <ul>

                <li> rosemary oil</li>
                <li> biotin</li>
                <li> vitamin A</li>
                <li> vitamin C</li>
                <li> vitamin E</li>



            </ul>
           
            <br>
            They keep your scalp healthy and nourish your hair follicles.
            <br> <br>
           <i>Avoid: Sulphates</i> 
            <br> <br> 
            These are often found in shampoos and are used to create a lather. According to Rimmer, they can irritate
            the scalp and negatively impact hair growth.


        </b>
            
            </p> <br> 
            <p>
            <h3>For nails</h3>
            <div class="image">
                <img src="nail.png">
            </div><b>
            The constant exposure to weather and water leaves  cuticles dry and brittle.
            <br> <br> 
            Her advice? Massage a drop of paraben-free nail oil into your cuticle.
            <br>
            This helps to mitigate against trauma and the temptation to pick at those hard dry bits of skin.
            <br> 
            <br>
            If you’re looking for a good all-rounder, Rimmer says a nightly collagen supplement drink can help hair,
            skin, and nails all in one go.
            <br> <br> 
           <i>Avoid: Using polish without a break</i> 
           <br>  <br> 
            I would always recommend giving your nails a regular break from wearing polish, whether it’s gel or
            norma. Allowing time for your nails to be exposed will result in healthier nails.

            
        </b></p>
        </div>
        <div class="post">
            <h2> Hair, skin, & nail conditions</h2>
            <br>
            <p><b>
                    <div class="image">
                        <img src="ddd.png">
                    </div>
                    <div class="image">
                        <img src="dame.png">
                    </div>
                    <br>
                    Some examples of conditions affecting hair, skin, and nail health include:<br>
                    <ul>

                        <li>eczema </li>
                        <li>alopecia</li>
                        <li>clubbing</li>
                        <li>folliculitis</li>
                        <li>psoriasis</li>
                        <li>onycholysis</li>
                        <li>yellow nail syndrome</li>



                    </ul>
                   
                    <br>  <br>
                    If you have any of these or another condition affecting your hair, skin, and nails, it’s a good idea
                    to check with your medical practitioner before using any new treatments.
                    <br>  <br>
                    These conditions are all potential indicators of underlying disease and would require a medical
                    assessment to investigate and a treatment plan provided by a healthcare professional.
                </b>
            </p>
        </div>
        <div class="post">
            <h2> Skin Patients Blogs </h2>
        </div>
</body>

</html>