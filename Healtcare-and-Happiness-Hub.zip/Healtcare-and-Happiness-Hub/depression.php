<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depression </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
            color: #050309;
        }

        header {
            background-color: #380b48;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #631969;
            padding: 10px;
            text-align: center;
        }

        nav {
            color: #ffffff;
            text-decoration: none;
            margin: 0 10px;
        }

        image {
            height: 90px;
            width: 90px;
            padding: 9%;

        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .post {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .post h2 {
            color: #060202;
        }

        .post p {
            color: #0a0202;
        }
    </style>
</head>

<body>
    <header>
        <h1>Depression </h1>
    </header>
    <br>
    <nav><b>.....People don't die from suicide, they die from sadness.....</b>
    </nav>
    <div class="container">
        <div class="post">
            <h2>Understanding Depression</h2>
            <div class="image">
                <img src="deprss.png">
            </div>


            <p><b>Depression is a mood disorder that causes a persistent feeling of sadness and loss of interest.<br>
                    Globally, an estimated 5% of adults suffer from depression.<br>
                    More women are affected by depression than men.<br>
                    Depression can lead to suicide.<br>
                    There is effective treatment for mild, moderate and severe depression.</b>
            </p>
        </div>
        <div class="post">
            <h2>Symptoms and patterns </h2>
            <div class="image">
                <img src="rr.png">
            </div>
            <p>
                <b>
                    During a depressive episode, a person experiences a depressed mood (feeling sad, irritable, empty).
                    They may feel a loss of pleasure or interest in activities.
                    <br><br>

                    A depressive episode is different from regular mood fluctuations. They last most of the day, nearly
                    every day, for at least two weeks.
                    <br><br>

                    Other symptoms are also present, which may include:

                    <ul>


                        <li> poor concentration</li>
                        <li> feelings of excessive guilt or low self-worth</li>
                        <li> hopelessness about the future </li>
                        <li> disrupted sleep</li>
                        <li> changes in appetite or weight</li>
                        <li>feeling very tired or low in energy.</li>


                    </ul>
                    <br>
                    Depression can cause difficulties in all aspects of life, including in the community and at home,
                    work and school.
                    <br><br>
                    A depressive episode can be categorized as mild, moderate, or severe depending on the number and
                    severity of symptoms, as well as the impact on the individual’s functioning.

                </b>
            </p>
        </div>

        <div class="post">
            <h2>Dignosis and treatment </h2>
            <div class="image">
                <img src="vv.png">
            </div>
            <p>
                <b>
                    

                    There are effective treatments for depression. These include psychological treatment and
                    medications. Seek care if you have symptoms of depression.
                    <br><br>
                    <h3>Psychological Treatment </h3>
                    Psychological treatments are the first treatments for depression. 
                    They can be combined with antidepressant medications in moderate and severe depression. Antidepressant medications are not
                    needed for mild depression.
                    <br><br>
                    Psychological treatments can teach new ways of thinking, coping or relating to others. 
                    They may include talk therapy with professionals and supervised lay therapists. 
                    <br><br>
                    Talk therapy can happen in person or online. Psychological treatments may be accessed through self-help manuals, websites and
                    apps.
                    <div class="image">
                        <img src="tp.png">
                    </div>
                    Effective psychological treatments for depression include:
                    <br>
                    <ul>


                        <li>behavioural activation</li>
                        <li>cognitive behavioural therapy</li>
                        <li> interpersonal psychotherapy</li>
                        <li>problem-solving therapy.</li>
                    </ul>
                    <h3>Medications</h3>
                    Antidepressant medications include selective serotonin reuptake inhibitors (SSRIs), such as
                    fluoxetine.
                    <br><br>
                    Health-care providers should keep in mind the possible adverse effects associated with
                    antidepressant medication, the ability to deliver either intervention (in terms of expertise, and/or
                    treatment availability), and individual preferences.
                    <br><br>
                    Antidepressants should not be used for treating depression in children and are not the first line of
                    treatment in adolescents, among whom they should be used with extra caution.

                    Different medications and treatments are used for bipolar disorder.
                </b>
            </p>
        </div>

        <div class="post">
            <h2> Self-care</h2>
            <div class="image">
                <img src="dd.png">
            </div>


            <p><b>Self-care can play an important role in managing symptoms of depression and promoting overall
                    well-being.</b>
                <br>
                <br>
                <b>What you can do:</b>
                <br><br>

                <b> 1.Try to keep doing activities you used to enjoy stay connected to friends and family regularly, even
                    if it’s just a short walk.<br><br>
                   2. stick to regular eating and sleeping habits as much as possible.<br><br>
                    3.Avoid or cut down on alcohol and don’t use illicit drugs, which can make depression worse.<br><br>
                   4. Talk to someone you trust about your feelings.<br><br>
                    5.Seek help from a healthcare provider.</b>
                <br><br>
            <h4><b> If you have thoughts of suicide:</b></h4>
        
            <b>
                <ul>
                    <li> Remember you are not alone, and that many people have gone through what you’re experiencing and found help</li><br>
                    <li> talk to someone you trust about how you feel talk to a health worker, such as a doctor or counsellor join a support group.</li><br>
                    <li> If you think you are in immediate danger of harming yourself, contact any available emergency services or a crisis line.</li><br>
                </ul>
            </b>
            </p>
        </div>
        <div class="post">
            <h2> Depression Patients Blogs </h2>
        </div>
</body>

</html>