<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depression </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
            color: #0c0816;
        }

        header {
            background-color: #604e84;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #07060e;
            padding: 10px;
            text-align: center;
        }

        nav {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .depress {
            height: 100px;
            width: 9%;
            padding: 90px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .post {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        image {
            height: 70px;
            width: 70px;
            padding: 9%;

        }

        .post h2 {
            color: #333;
        }

        .post p {
            color: #666;
        }
    </style>
</head>

<body>
    <header>
        <h1>Migraine </h1>
    </header>
    <br>
    <nav><b></b>
    </nav>
    <div class="container">
        <div class="post">
            <h2>Migraine</h2>
            <div class="image">
                <img src="kk.png">
            </div>

            </h2>

            <p><b>
                    Migraine is a neurological condition that typically causes painful headache attacks that occur with
                    additional symptoms, such as sensitivity to light, sound, smell, or touch.
                    <br> <br>
                    Migraine is a type of headache that causes moderate to severe throbbing or pulsating pain on one
                    side of the head.
                    <br>
                    <br> Migraines are more common in the morning, especially upon waking<br>
                    More than just the cause of “really bad headaches,” migraine is a neurological condition that can
                    cause multiple symptoms.<br>
                    <br>While intense, debilitating headaches frequently characterize it,
                    additional symptoms may include:
                    <br>
                    <ul>


                        <li>Snoozing</li>
                        <li> nausea</li>
                        <li> vomiting</li>
                        <li>numbness or tingling </li>
                        <li> sensitivity to light and sound </li>



                    </ul>


                    <br>
                    The condition often runs in families and can affect all ages.<br>
                    People assigned female at birth are more likely than people assigned male at birth to be diagnosed
                    with migraine.<br>
                    The diagnosis of migraine is determined based on clinical history, reported symptoms, and by ruling
                    out other causes.<br> The most common categories of migraine headaches (or attacks) are episodic
                    versus
                    chronic, and then those without aura and those with aura.

                </b>
            </p>
        </div>
        <div class="post">
            <h2> What does migraine feel like ?</h2>
            <div class="image">
                <img src="feel.png">
            </div>

            </h2>


            <p>
                <b>
                    <h4> People describe migraine pain as:</h4>
                    <br>
                    <ul>

                        <li>pulsating </li>
                        <li>throbbing </li>
                        <li>pounding</li>
                        <li>debilitating </li>
                        <li> perforating</li>



                    </ul>


                    <br>
                    It can also feel like a severe, dull, steady ache. <br>
                    The pain may start out as mild. But without treatment, it can become moderate to severe. <br>

                    Migraine pain most commonly affects the forehead area. <br> <br>
                    It’s usually on one side of the head, but it can occur on both sides or shift.
                    <br><br>
                    Most migraine attacks last about 4 hours.
                    If they’re not treated or don’t respond to treatment, they can last for as long as 72 hours to a
                    week. <br> <br>
                    In migraine with aura, pain may overlap with an aura or may never occur at all.

                    <br><br>
                </b>
            </p>
        </div>
        <div class="post">
            <h2> What causes migraine attacks?</h2>
            <div class="image">
                <img src="migr.png">
            </div>

            </h2>


            <p>
                <b>
                    Researchers haven’t identified a definitive cause for migraine.
                    <br>But they still believe the condition
                    is due to “abnormal” brain activity that affects nerve signaling, and chemicals and blood vessels in
                    the brain.
                    <br> <br>
                    There are also many migraine triggers that are continually reported, including:
                    <br>

                    <li> bright lights </li>
                    <li> severe heat, or other extremes in weather</li>
                    <li>dehydration</li>
                    <li>changes in barometric pressure</li>
                    <li>hormone changes in people assigned female at birth, like estrogen and progesterone fluctuations
                    </li>
                    <li>during menstruation, pregnancy, or menopause</li>
                    <li> excess stress</li>
                    <li>loud sounds</li>
                    <li> intense physical activity</li>
                    <li> traveling</li>
                    <li>changes in sleep patterns</li>
                    <li>certain foods</li>
                    <li>alcohol use</li>


                    <br>

                    If you experience a migraine attack, your doctor may ask you to keep a headache journal.
                    <br>
                    Writing down what you were doing, what foods you ate, and what medications you took before your
                    migraine attack began can help identify your triggers.

                    <br><br>

                </b>

            </p>
        </div>
        <div class="post">
            <h2> Migrane Treatment</h2>
            <div class="image">
                <img src="nnn.png">
            </div>

            </h2>


            <p>

                <b>
                    Migraine can’t be cured, but your doctor can help you manage migraine attacks by giving you the
                    tools to treat symptoms when they occur, which may lead to fewer attacks in general. <br> <br>
                    Treatment can also help make migraine less severe.
                    <br>
                    <h3>Your treatment plan depends on:</h3>
                    <br>
                    <li> your age </li>
                    <li>how often you have migraines attacks</li>
                    <li> the type of migraine you have </li>
                    <li> how severe they are </li>

                    <br><br>
                    based on how long they last, how much pain you have, and how often they keep you from going to
                    school or work. <br><br>
                    
                    <div class="image">
                        <img src="fff.png">
                    </div>
                    whether they include nausea or vomiting, as well as other symptoms other health conditions you may
                    have and other medications you may take Your treatment plan may include a combination of:
                    <br> <br>
                    <li> lifestyle adjustments, including stress management and avoiding migraine triggers
                        OTC pain or migraine medications, like Nonsteroidal anti-inflammatory drugs (NSAIDs) or
                        acetaminophen (Tylenol). </li>
                        <br>
                    <li>prescription migraine medications that you take every day to help prevent migraine headaches and
                        reduce how often you have headaches.<br>
                        prescription migraine medications that you take as soon as an attack starts to keep it from
                        becoming severe and to ease symptoms.</li>
                        <br>
                    <li> prescription medications to help with nausea or vomiting.<br>
                        hormone therapy if migraines seem to occur in relation to your menstrual cycle
                        counseling.</li>


                    <br>

                </b>

            </p>
        </div>

        <div class="post">
            <h2> Migraine Patients Blogs </h2>
        </div>
        <footer>
            footer
        </footer>

</body>

</html>