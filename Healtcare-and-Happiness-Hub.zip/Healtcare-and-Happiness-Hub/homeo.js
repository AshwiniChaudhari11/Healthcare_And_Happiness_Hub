// Data for diseases and corresponding Homeopathic remedies
var homeopathicRemedies = {
    "common cold": ["Aconite", "Allium Cepa", "Arsenicum Album"],
    "flu": ["Gelsemium", "Bryonia", "Eupatorium Perfoliatum"],
    "allergies": ["Sabadilla", "Allium Cepa", "Natrum Muriaticum"],
    "pneumonia": ["Antimonium Tartaricum", "Bryonia", "Phosphorus"],
    "asthma": ["Arsenicum Album", "Sambucus Nigra", "Ipecacuanha"],
    "strep throat": ["Belladonna", "Mercurius Solubilis", "Phytolacca"]
};

var homeopathicRemediesWithDescriptions = {
    "common cold": [
        { name: "Aconite", description: "For the sudden onset of cold with fever, anxiety, and restlessness. Symptoms include sudden onset of symptoms, high fever, anxiety, restlessness, and thirst." },
        { name: "Allium Cepa", description: "For cold with profuse watery nasal discharge and bland eye secretions. Symptoms include profuse watery nasal discharge that irritates the upper lip, bland eye secretions, and frequent sneezing." },
        { name: "Arsenicum Album", description: "For cold with thin, watery discharge and burning sensations. Symptoms include thin, watery nasal discharge, burning sensations in the nose, eyes, and throat, and restlessness." }
    ]
};

// Flu:
// Gelsemium: Description not available.
// Bryonia: Description not available.
// Eupatorium Perfoliatum: Description not available.
// Allergies:
// Sabadilla: Description not available.
// Allium Cepa: Description not available.
// Natrum Muriaticum: Description not available.
// Pneumonia:
// Antimonium Tartaricum: Description not available.
// Bryonia: Description not available.
// Phosphorus: Description not available.
// Asthma:
// Arsenicum Album: Description not available.
// Sambucus Nigra: Description not available.
// Ipecacuanha: Description not available.
// Strep Throat:
// Belladonna: Description not available.
// Mercurius Solubilis: Description not available.
// Phytolacca: Description not available.

function getHomeopathicSolution() {
    var disease = document.getElementById("healthCondition").value;
    var solution = document.getElementById("solution");

    if (disease in homeopathicRemediesWithDescriptions) {
        solution.innerHTML = "<h3>Homeopathic Remedies for " + disease + ":</h3>";
        var remediesList = "<ul class='solution-list'>";
        homeopathicRemediesWithDescriptions[disease].forEach(function(remedy) {
            remediesList += "<li><b>" + remedy.name + ":</b></li>";
            remediesList += "<p>" + remedy.description + "</p>";
        });
        remediesList += "</ul>";
        solution.innerHTML += remediesList;
    } else if (disease in homeopathicRemedies) {
        solution.innerHTML = "<h3>Homeopathic Remedies for " + disease + ":</h3>";
        var remediesList = "<ul class='solution-list'>";
        homeopathicRemedies[disease].forEach(function(remedy) {
            remediesList += "<li>" + remedy + "</li>";
        });
        remediesList += "</ul>";
        solution.innerHTML += remediesList;
    } else {
        solution.innerHTML = "<p>No remedies found for " + disease + ".</p>";
    }
}

